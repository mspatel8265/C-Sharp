﻿using System;
namespace CollegeConsole
{
    [Serializable]
    public enum FinalGrade
    {
        Aplus,
        A,
        Bplus,
        B,
        Cplus,
        C,
        Dplus,
        D,
        F

    }
}
