﻿using System;
namespace CollegeConsole
{
    [Serializable]
    public enum EvaluationType
    {
        TEST,
        LAB,
        QUIZ,
        ASSIGNMENT

    }
}
