﻿using System;
namespace CollegeConsole
{
    [Serializable]
    public enum SemesterPeriod
    {
        FALL,
        WINTER,
        SUMMER
    }
}
